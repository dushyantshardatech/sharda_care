<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Admin\CommonModel;
use Illuminate\Support\Facades\Validator;

class HomeController extends Controller
{
    protected $CommonModel;
    public function __construct(CommonModel $commonModel)
    {
        $this->commonModel = $commonModel;
    }
    public function index()
    {
        $data['banners']            = $this->commonModel->viewData('tbl_banners','*',['mainmenu_id' => 1, 'status' => '1', 'is_deleted' => '0']);
        $data['medical_packages']   = $this->commonModel->viewData('tbl_medical_packages','*',['status' => '1', 'is_deleted' => '0']);
        $data['stories_list']       = $this->commonModel->viewData('tbl_ourstories','*',['status' => '1', 'is_deleted' => '0']);
        return view('pages.home', $data);
    }
    public function About()
    {
        return view('pages.about');
    }
    

    public function find_doctor(Request $request)
    {
        $query = \DB::connection('mysql2')
                    ->table('sh_doctorprofile')
                    ->leftJoin('sh_departments', 'sh_doctorprofile.DoctorDepartment', '=', 'sh_departments.DepartmentID')
                    ->select('sh_doctorprofile.DoctorID', 'sh_doctorprofile.DoctorTitle', 'sh_doctorprofile.DoctorName', 'sh_doctorprofile.DoctorGender', 'sh_doctorprofile.DoctorProfilePic', 'sh_departments.DepartmentID', 'sh_departments.DepartmentName');
        
        if ($request->ajax()) {
            $department = $request->input('department');
            $gender = $request->input('gender');
            $doctorName = $request->input('doctorName');
           
            if (!empty($department)) {
                $query->where('sh_doctorprofile.DoctorDepartment', $department);
            }
            
            if (!empty($gender) && $gender !== 'All' && empty($department)) {
                $query->where('sh_doctorprofile.DoctorGender', $gender);
            }
    
            if(!empty($doctorName)){
                
                $query->where('sh_doctorprofile.DoctorName', 'LIKE', '%' . $doctorName . '%');
            }
           
            
            $data = $query->get();
        
            return response()->json([
                'data' => $data,
            ]);
        }
        
        // If not an AJAX request, just for default case
        $data = $query->get();
        $doctorDepartments = \DB::connection('mysql2')
                                    ->table('sh_departments')
                                    ->pluck('DepartmentName', 'DepartmentID');
        
        return view('pages.find_doctor', ['data' => $data, 'doctorDepartments' => $doctorDepartments]);
    }


    public function contacts (Request $request)
    {
        return view('pages.contact');
    }    
    public function store_contact (Request $request)
    {
        $validator = Validator::make($request->all(), [
            'fname' => 'required|string|max:255',
            'lname' => 'required|string|max:255',
            'phone' => 'required|string|max:10', 
            'email' => 'required|email|max:255',
            'city' => 'required|string|max:255',
            'country' => 'required|string|max:255',
            'message' => 'required|string|max:255',
            
        ]);
    
       
        if ($validator->fails()) {
           
            return  redirect()->back()->with([
                'success' => false,
                'message' => $validator->errors(),
               
            ], 422);
        }
    
        
        $validatedData = $validator->validated();
    
        try {
          
            \DB::connection('mysql')->table('tbl_contact')->insert([
                'fname' => $validatedData['fname'],
                'lname' => $validatedData['lname'],
                'phone' => $validatedData['phone'],
                'email' => $validatedData['email'],
                'city' => $validatedData['city'],
                'country' => $validatedData['country'],
                'message' => $validatedData['message'],
                
            ]);
    
            // Return a success response
            return redirect()->back()->with('message',"Thanks For Contacting Us!");
    
    
        } catch (\Exception $e) {
           
            return redirect()->back()->with([
                'success' => false,
                'message' => 'Failed to book Contacting.',
                'error' => $e->getMessage()
            ], 500);
        }
        
    }
    public function patient_visits()
    {
        return view('pages.patient_visit');
    }
    public function Medicalpackage()
    {
        return view('pages.medical_packages');
    }

    
    public function doctorDetails($id = null)
    {
        
       $doctor_details = \DB::connection('mysql2')
                                ->table('sh_doctorprofile')
                                ->leftJoin('sh_departments', 'sh_doctorprofile.DoctorDepartment', '=', 'sh_departments.DepartmentID')
                                ->leftJoin('sh_designations', 'sh_doctorprofile.DoctorDesignation', '=', 'sh_designations.DesignationID')
                                ->where('sh_doctorprofile.DoctorID',$id)
                                ->get();
                        
        return view('pages.doctor_details', ['doctor_details' => $doctor_details]);
    }


    // Quick Enquery

    public function quickEnquiry(Request $request){
        
            // Define validation rules
            $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255',
            'phone' => 'required|string|max:10', 
            'email' => 'required|email|max:255',
            
        ]);
    
        
        if ($validator->fails()) {
            
            return  redirect()->back()->with([
                'success' => false,
                'message' => $validator->errors(),
                
            ], 422);
        }
    
        
        $validatedData = $validator->validated();
    
        try {
        
            \DB::connection('mysql')->table('tbl_quick_enquiry')->insert([
                'name' => $validatedData['name'],
                'phone' => $validatedData['phone'],
                'email' => $validatedData['email'],
                'time_to_call' => now(),
            ]);
    
            // Return a success response
            return redirect()->back()->with('message',"Enquire successfully!");
    
    
        } catch (\Exception $e) {
            return redirect()->back()->with([
                'success' => false,
                'message' => 'Failed to Enquire.',
                'error' => $e->getMessage()
            ], 500);
        }
     }


    public function bookAppointment(Request $request){
       // Define validation rules
       $validator = Validator::make($request->all(), [
        'name' => 'required|string|max:255',
        'phone' => 'required|string|max:10', 
        'email' => 'required|email|max:255',
        'doctor_name' => 'required|string|max:255',
    ]);

   
    if ($validator->fails()) {
       
        return  redirect()->back()->with([
            'success' => false,
            'message' => $validator->errors(),
           
        ], 422);
    }

    
    $validatedData = $validator->validated();

    try {
      
        \DB::connection('mysql2')->table('sh_book_appointment')->insert([
            'name' => $validatedData['name'],
            'phone' => $validatedData['phone'],
            'email' => $validatedData['email'],
            'doctor_name' => $validatedData['doctor_name'],
        ]);

        // Return a success response
        return redirect()->back()->with('message',"Appointment booked successfully!");


    } catch (\Exception $e) {
        return redirect()->back()->with([
            'success' => false,
            'message' => 'Failed to book appointment.',
            'error' => $e->getMessage()
        ], 500);
    }
    }


    public function Packagedetails($slug)
    {
        $package_details    = $this->commonModel->viewData('tbl_medical_packages', '*', ['slug' => $slug])->first();
        if (!$package_details) {
            abort(404);
        }
        return view('pages.medi_pkg_details', compact('package_details'));
    }
}
