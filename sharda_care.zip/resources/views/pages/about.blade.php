@extends('layout')
@section('page_title', 'About')
@section('page-contents')
<div class="slider-innerpage">
	<div class="container">
    	<div class="row">
        	<div class="col-md-12">
            	<h1>About Us</h1>
       		</div> 
        </div>
    </div>
</div>

 <br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br />

@endsection