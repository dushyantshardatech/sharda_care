@extends('layout')
@section('page_title', 'Contact Us')
@section('page-contents')
<div class="slider-innerpage">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1>Contact Us</h1>
            </div>
        </div>
    </div>
</div>
<section class="contacts">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-4">
                <div class="contact-detail contact-detail-add">
                    <h4>Contact Details</h4>
                    <p>Want to get in touch? Please reach out to the following contact details</p>

                    <ul>
                        <li><i class="bi bi-globe" aria-hidden="true"></i> Plot No. 32-34, Knowledge Park III,Greater Noida, Uttar Pradesh 201310</li>
                        <li><i class="bi bi-envelope" aria-hidden="true"></i> info@sharda.ac.in</li>
                        <li><i class="bi bi-phone" aria-hidden="true"></i> +0120–36-99-999</li>
                    </ul>
                </div>
            </div>
            <div class="col-md-7">
            @if(session('message'))
                <h6 class="alert alert-success">
                    {{ session('message') }}
                </h6>
            @endif
              <form action="{{ route('store_contact')}}" method="POST">
                @csrf
                <div class="contact-form">
                    <h4>Get in Touch</h4>
                    <p>Please submit your query in the following form.</p>
                    <div class="row justify-content-center">
                        <div class="col-md-6"><input type="text" name="fname" id="name" placeholder="First Name" /></div>
                        <div class="col-md-6"><input type="text" name="lname" id="name" placeholder="Last Name" /></div>
                    </div>
                    <div class="row justify-content-center">
                        <div class="col-md-6"><input type="text" name="phone" id="name" placeholder="Contact Number " /></div>
                        <div class="col-md-6"><input type="text" name="email" id="name" placeholder="Email ID" /></div>
                    </div>
                    <div class="row justify-content-center">
                        <div class="col-md-6"><input type="text" name="city" id="name" placeholder="City " /></div>
                        <div class="col-md-6"><input type="text" name="country" id="name" placeholder="Country" /></div>
                    </div>
                    <div class="row justify-content-center">
                        <div class="col-md-12"><textarea name="message" id="message" placeholder="Your Enquiry"></textarea></div>
                    </div>

                    <div class="row justify-content-center">
                        <div class="col-md-12">
                            <button id="submit" value="Submit" name="submit" onclick="return validateregistrationform()" class="button1">Submit <i class="bi bi-arrow-right"></i></button>
                        </div>
                    </div>
                </div>
              </form>
            </div>
        </div>
    </div>
</section>

@endsection