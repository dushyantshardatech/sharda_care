@extends('layout')
@section('page_title', 'Medical Package')
@section('page-contents')
<h1>Medical Package</h1>
@endsection